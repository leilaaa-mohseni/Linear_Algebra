import numpy as np
import time
# import matplotlib.pyplot as plt

def op_scale(A,R,C):
    dimensions = A.shape
    rows, columns = dimensions
    for i in range(columns):
        A[R,i]= C*A[R,i]
    return(A)

def op_interchange(A, R1, R2):
    A[[R1, R2]] = A[[R2, R1]]
    return(A)

def op_replace(A, R1, R2 , C):
    dimensions = A.shape
    rows, columns = dimensions
    for j in range(columns):
        A[R2,j]=A[R2,j] + C*(A[R1,j])
    return(A)
    
A = np.array([[10, 3, 2, 1],
               [ 1, 0, 4, 2],
               [ 7, 5,-1, 9],
               [-6,-7, 8,-4]])

#testing 
# print(op_scale(A,1,3))
# print(op_interchange(A, 2, 3))
# print(op_replace(A, 1, 0, 4))

def findNonezeroRow(matrix, pivotRow, col):
    countRow = matrix.shape[0]
    for i in range(pivotRow, countRow):
        if matrix[i, col] != 0:
            return i
    return None

def makePivotOne(matrix, pivotRow, col):
    for i in range(0,pivotRow):
        pivotElement = matrix[i, col]
        matrix[i] = matrix[i] - (pivotElement * matrix[pivotRow])
    
def eliminateBelow(matrix, pivotRow, col):
    nrows = matrix.shape[0]
    for i in range(pivotRow + 1, nrows):
        factor = matrix[i, col]
        matrix=op_replace(matrix,pivotRow,i,factor*(-1))

def row_echelon(matrix):
    rows = matrix.shape[0]
    columns = matrix.shape[1]
    pivot = 0
    scaling = 1
    for col in range(columns):
        not_zero = findNonezeroRow(matrix, pivot, col)
        if not_zero is not None:
            if pivot != not_zero:
              scaling = scaling * (-1)
            matrix=op_interchange(matrix,pivot,not_zero)
            scaling = scaling * (matrix[pivot, col])
            matrix = op_scale(matrix,pivot,1/matrix[pivot,col])
            eliminateBelow(matrix, pivot, col)
            pivot = pivot + 1
            if pivot == rows:
                break

    return matrix,scaling
    
# testing 
# B = np.asfarray([[ 1, 2, 3, 4],
#               [ 5, 6, 7, 8],
#               [ 9,10,11,12]])
# list1=row_echelon(B)
# print(list1[0])

def reduce(matrix):
    rows, cols = matrix.shape
    lead = 0
    for r in range(rows):
        if lead >= cols:
            return matrix
        i = r
        while matrix[i, lead] == 0:
            i += 1
            if i == rows:
                i = r
                lead += 1
                if lead == cols:
                    return matrix
        matrix[[i, r]] = matrix[[r, i]]
        lv = matrix[r, lead]
        matrix[r] /= lv
        for i in range(rows):
            if i != r:
                lv = matrix[i, lead]
                matrix[i] -= lv * matrix[r]
        lead += 1
    return matrix

# testing 
# B = np.array([[ 1, 2, 3, 4],
#               [ 0,-4,-8,-12],
#               [ 0, 0, 0, 0]],dtype=float)
# print(reduce(B))

def find_pivot_columns(matrix):
    rows, cols = matrix.shape
    pivot_columns = []
    for j in range(cols):
        pivot_found = False
        for i in range(rows):
            if matrix[i, j] == 1:
                pivot_found = True
                break
        if pivot_found:
            pivot_columns.append(j)
    return pivot_columns

def find_free_columns(matrix):
    pivot_columns = find_pivot_columns(matrix)
    rows, cols = matrix.shape
    free_variables = [col for col in range(cols-1) if col not in pivot_columns]
    return free_variables

def is_consistent(matrix):
    for row in matrix:
        if np.all(row[:-1] == 0) and row[-1] != 0:
            return False
    return True

def is_unique(A):
    free_variable=find_free_columns(A)
    if(len(free_variable)==0):
        return True
    else:
        return False
 
# testing    
# B = np.array([[ 1, 2, 3, 4],
#               [ 0,-4,-8,-12],
#               [ 0, 0, 0, 0]])

# print(is_consistent(B))
# print(is_unique(B))


def solve_with_free_var(A,defalte_free_var):
    free_var = find_free_columns(A)
    basic_var =find_pivot_columns(A) 
    sum=0
    rows, cols = A.shape
    variables=[0]*(cols-1)
    for i in range (cols):
        if i in free_var:
            variables[i]=defalte_free_var
            
    for i in range(cols):
        if(free_var.count(i)==0):
            for k in range(rows):
                if A[k,i]==1:
                    sum=-(np.sum(A[k,i+1:cols-1]))
                    sum+=A[k,cols-1]
                    variables[basic_var[k]]= round(sum,2)
                    sum=0
    return(variables)

def solve_without_free_var(A):
    cols=A.shape[1]
    count_pivot_col=len(find_pivot_columns(A))
    solution=list()
    for i in range (count_pivot_col-1):
        solution.append(A[i,cols-1])
    return solution

    
def solve(A):
    other_columns = A[:, :-1]
    last_column = A[:, -1]
    if(is_consistent(A)==False):
        print("No solution ")
    elif (is_unique(A)==True):
        print(solve_without_free_var(A))
        if(np.allclose(np.dot(other_columns,solve_without_free_var(A)),last_column)==True):
            print("True solution ")
        else:
            print("False solution ")
    else:
        solution=(solve_with_free_var(A,1.00))
        print(solution)
        if(np.allclose(np.dot(other_columns,solution),last_column)==True):
            print("True solution ")
        else:
            print("False solution ")

# testing 
#the example matrices are redused echlon form 
# A1=np.array([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])
# A2=np.array([[1,0,0,1.8,-2.48],[0,1,0,-0.7,-0.88],[0,0,1,-1.5,-0.6]])
# A3=np.array([[1,0,0,1],[0,1,0,8],[0,0,1,1]])
# solve(A1)
# solve(A2)
# solve(A3)


def det_recursive(A):
    rows,cols=A.shape
    if(rows!=cols):
        return "We can not calculate determinan of this matrix "
    else:
        n = len(A)
        if n == 1:
            return A[0, 0]
        elif n == 2:
            return A[0, 0] * A[1, 1] - A[0, 1] * A[1, 0]
        else:
            det = 0
            for j in range(n):
                minor_matrix = np.delete(A, 0, axis=0)
                minor_matrix = np.delete(minor_matrix, j, axis=1)
                det += ((-1) ** j) * A[0, j] * det_recursive(minor_matrix)
            return det

#testing 
# Matrix = np.array([[ 5, 7,-2, 1],
#                    [-1, 5,-3, 0],
#                    [ 3,11,-2,-9],
#                    [ 8, 0, 4,-1]])
# print(det_recursive(Matrix))

matrixes=[]
m2=np.asfarray([[2,3],[9,8]])
m3=np.asfarray([[2,3,1],[9,8,5],[9,3,2]])
m4=np.asfarray([[1,6,4,3],[9,8,1,6],[4,3,1,1],[4,3,1,2]])
m5=np.asfarray([[1,5,4,0,6],[2,4,8,9,1],[6,5,1,0,4],[4,3,9,8,0],[1,2,9,8,6]])
m6=np.asfarray([[3,2,1,6,7,4],[1,5,7,3,0,1],[3,6,9,1,0,4],[5,3,1,9,1,1],[1,6,9,2,3,1],[6,5,4,1,9,0]])
m7=np.asfarray([[2,1,0,8,6,5,4],[4,3,1,8,7,2,3],[6,5,3,9,1,7,1],[6,4,1,0,8,6,2],[1,2,7,6,5,3,1],[7,5,2,9,1,0,0],[8,6,5,3,1,9,0]])
matrixes.append(m2)
matrixes.append(m3)
matrixes.append(m4)
matrixes.append(m5)
matrixes.append(m6)
matrixes.append(m7)

# Testing
elapsed_time_recursive=[0]*6
for i in range(6):
    start_time = time.time()
    d1 = det_recursive(matrixes[i])
    end_time = time.time()
    print(d1)
    elapsed_time_recursive[i] = end_time - start_time
    print(f"Time Elapsed for recursive computation of determinant of matrix{i+2} : " , elapsed_time_recursive[i])


def det_row_echelon(matrix):
    newMatrix= row_echelon(matrix)
    rows = matrix.shape[0]
    columns = matrix.shape[1]
    answer = 1
    for i in range(rows):
        answer *= matrix[i, i]
    answer *= newMatrix[len(newMatrix)-1]
    return round(answer)

# B = np.asfarray([[5,7,-2,1],
#               [-1,5,-3,0],
#               [3,11,-2,-9],[8,0,4,-1]])

# print(det_row_echelon(B))


print("-----------------------------------------------------------------------------")


# Testing
elapsed_time_rowechelon=[0]*6
for i in range(6):
    start_time = time.time()
    d1 = det_row_echelon(matrixes[i])
    end_time = time.time()
    print(d1)
    elapsed_time_rowechelon[i] = end_time - start_time
    print(f"Time Elapsed for row_echlon computation of determinant of matrix{i+2} : " , elapsed_time_rowechelon[i])



# compere 2 functions 
# x = np.array(2,3,4,5,6,7)
# y = elapsed_time_recursive
# z = elapsed_time_rowechelon
# plt.plot(x, y, color='r', label='det_recursive') 
# plt.plot(x, z, color='g', label='det_echlon')
# plt.xlabel("size_matrix") 
# plt.ylabel("det") 
# plt.title("compere 2 function")   
# plt.legend() 
# plt.show() 

##According to the graphs, we understand that:
##Recursive:
# This method is usually suitable for small matrices. 
# Its implementation is simple and understandable, and it usually works well for small matrices. 
# Its disadvantage is that for larger matrices, its execution time is very long and it may encounter problems.
##Echlon
# This method is effective for large matrices with a special structure and can be converted into the echelon form
# For larger matrices with proper structure, it has optimal and fast performance.
# Its disadvantage is that its implementation is more complicated than the recursive method and it is not suitable for matrices with a complex structure that cannot be converted to the echelon form.




#Extra
# A2=np.array([[1,0,0,1.8,-2.48],[0,1,0,-0.7,-0.88],[0,0,1,-1.5,-0.6]])
# print(find_free_columns(A2))
# if (len(find_free_columns(A2))==1):
#     k=find_free_columns(A2)[0]
#     u=find_pivot_columns(A2)
#     all_solution=[]
#     for i in range(1,4):
#         solution=solve_with_free_var(A2,i)
#         # for j in range(len(u)):
#         #     plt.plot(solution[k-1],solution[u[j-1]] , label='2d projection')
#         all_solution.append(solution)
#     free_var=[]
#     pivot_var=[]
#     for i in range(len(all_solution)):
#         free_var.append(all_solution[i][k-1])
#     for j in range(len(all_solution)):
#         for t in range(len(u)):
#             pivot_var.append(all_solution[j][u[t-1]])
#     fig = plt.figure()
#     ax = fig.add_subplot(111, projection='3d')
#     for f in range(len(pivot_var)):
#         ax.plot(free_var[0],pivot_var[i],"projection='3d'")
      
# elif(len(find_free_columns(A2))==2)   :
#     k1=find_free_columns(A2)[0]
#     k2=find_free_columns(A2)[1]
#     u=find_pivot_columns(A2)
#     for i in range(1,4):
#         solution=solve_with_free_var(A2,i)
#         for j in range(len(u)):
#                 plt.plot(solution[k1-1],solution[k2-1],solution[u[j]-1] , label=f"pivot_column{j}")

    

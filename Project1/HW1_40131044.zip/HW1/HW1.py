import numpy as np
# This function is for checking non-zero rows
def findNonezeroRow(matrix, pivotRow, col):
    countRow = matrix.shape[0]
    for i in range(pivotRow, countRow):
        if matrix[i, col] != 0:
            return i
    return -1

# This function for make a pivot position 
def makePivotOne(matrix, pivotRow, col):
    pivotElement = matrix[pivotRow, col]
    matrix[pivotRow] = matrix[pivotRow] /pivotElement
    
#This function is for zeroing all the elements under the axial layer. This is done by multiplying the element under the axial element in the first row and then subtracting it from the second row.
def eliminateBelow(matrix, pivotRow, col):
    nrows = matrix.shape[0]
    for i in range(pivotRow + 1, nrows):
        factor = matrix[i, col]
        matrix[i] = matrix[i] - (factor * matrix[pivotRow]) 

#In this function, we will use all the functions we have defined above
def rowEchelonForm(matrix):
    countCol = matrix.shape[1]
    pivotRow = 0
    for col in range(countCol):
        nonzeroRow = findNonezeroRow(matrix, pivotRow, col)
        if nonzeroRow != -1:
            matrix[[pivotRow, nonzeroRow]] = matrix[[nonzeroRow, pivotRow]]
            makePivotOne(matrix, pivotRow, col)
            eliminateBelow(matrix, pivotRow, col)
            pivotRow +=1
    return matrix

#This function is reduced to convert the matrix to the echelon form
def ToReducedRowEchelonForm( Matrix):
    if not Matrix: return
    lead = 0
    rowCount = len(Matrix)
    columnCount = len(Matrix[0])
    for r in range(rowCount):
        if lead >= columnCount:
            return
        i = r
        while Matrix[i][lead] == 0:
            i += 1
            if i == rowCount:
                i = r
                lead += 1
                if columnCount == lead:
                    return
        Matrix[i],Matrix[r] = Matrix[r],Matrix[i]
        lv = Matrix[r][lead]
        Matrix[r] = [ mrx / float(lv) for mrx in Matrix[r]]
        for i in range(rowCount):
            if i != r:
                lv = Matrix[i][lead]
                Matrix[i] = [ iv - lv*rv for rv,iv in zip(Matrix[r],Matrix[i])]
        lead += 1
        
#This function is for checking whether we have a row in which all the digits except the last one are zero or not.
def checkZeroRow(matrix):
    for row in matrix:
        if np.array_equal(row[:-1], 0) and row[-1] != 0:
            return True
    return False

#This function is for checking whether the device has a unique answer or not, which is one of the conditions that the number of rows is equal to one less than the number of columns.
def isUniqueSolution(matrix1):
    rowCount=matrix1.shape[0]
    colCount=matrix1.shape[1]
    if(rowCount==colCount-1):
        return True
    else:
        return False
    
#This function is for solving the device with a free variable that sets its default value to one
def solveSystemWithFreeVariable(Matrix1, defaultValue=1):
    A = Matrix1[:, :-1]
    b = Matrix1[:, -1]
    solution = np.linalg.lstsq(A, b, rcond=None)[0]
    solution = np.append(solution, defaultValue)
    return solution

#main function
command1=input()
spaceSplit=command1.split(' ')
command2=input()
flashSplit=command2.split('->')
plasList1=flashSplit[0].split('+')
plasList2=flashSplit[1].split('+')
plasList2[len(plasList2)-1]=plasList2[len(plasList2)-1]+" "

MyMatrix=np.zeros((len(spaceSplit),len(plasList1)+len(plasList2)+1),int)
for k in range (len(spaceSplit)):
    for t in range (len(plasList1)):
                     findCharacter=plasList1[t].find(spaceSplit[k])
                     if(findCharacter!=-1):
                        y=plasList1[t].index(spaceSplit[k])
                        if(plasList1[t][y+1].isdigit()==True):
                            MyMatrix[k][t]=int(plasList1[t][y+1])
                        elif(plasList1[t][y+1].isalpha()==True or plasList1[t][y+1]==' '):
                            MyMatrix[k][t]=1


for k in range (len(spaceSplit)):
    for t in range (len(plasList2)):
                     findCharacter=plasList2[t].find(spaceSplit[k])
                     if(findCharacter!=-1):
                        y=plasList2[t].index(spaceSplit[k])
                        if(plasList2[t][y+1].isdigit()==True):
                                MyMatrix[k][t+len(plasList1)]=-(int(plasList2[t][y+1]))
                        elif(plasList2[t][y+1].isalpha()==True or plasList2[t][y+1]==' '):
                                MyMatrix[k][t+len(plasList1)]=-1

print(MyMatrix) 
# print("--------------")  
# print("Row echelon form  of MyMatrix")
# print(rowEchelonForm(MyMatrix))
# print("-----------------")
listMatrix=list(MyMatrix)
ToReducedRowEchelonForm(listMatrix)
MyMatrix2=np.array(listMatrix)
print(" Reduce row echelon form  of MyMatrix")
print(MyMatrix2)
print("Solution set of matrix:")
A= MyMatrix2[:, :-1] 
b = MyMatrix2[:, -1]   
if(checkZeroRow(MyMatrix2)):
    print("Solution is null") 
if (isUniqueSolution(MyMatrix2)==True):
        x = np.linalg.solve(A, b)
        print(x)
else:
       solution=solveSystemWithFreeVariable(A)
       for i in range(len(solution)):
           roundNumber=round(solution[i],2)
           print(f"x{i+1}:{abs(roundNumber)}")

